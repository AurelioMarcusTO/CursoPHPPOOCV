<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <pre>
        <?php
        require_once 'Caneta.php' ;
        
        $c1 = new Caneta("BIC", "Azul", 0.5);
        $c2 = new Caneta("Clic", "Preta", 1.0);
        
        print_r($c1);
        print_r($c2);
        
        print "Eu tenho uma caneta modelo {$c1->getModelo()} da cor {$c1->getCor()} com ponta {$c1->getPonta()}.<br/>";
        
        print "Eu tenho uma caneta modelo {$c2->getModelo()} da cor {$c2->getCor()} com ponta {$c2->getPonta()}.<br/>";
        
        ?>
        </pre>
    </body>
</html>
