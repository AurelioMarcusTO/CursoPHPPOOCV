<?php

class Carro {
    var $modelo ;
    var $tipo ;
    var $cor ;
    var $motor ;
    var $combustivel ;
    var $abastecimento ;
    var $rodas ;
    var $pneu ;
    
    function rodar() {
        if ($this->abastecimento >= 30) {
            echo "<p>Estou rodando pelas ruas ... Vruummm !</p>" ;
        } else {
            echo "<p>Não posso rodar estou sem combustível ...</p>" ;
        }
    }
    function correr() {
        if ($this->motor >= 1.8) {
            echo "<p>Sou potente e posso correr ...Uau !!!</p>" ;
        } else {
            echo "<p>Meu motor é fraco não posso correr ... AAhhh !!!</p>" ;
        }
        
    }
    function estacionar() {
        echo "<p>Estou estacionado ....<p/>" ;
        $this->abastecimento = false ;
    }
    
    function calibrar() {
        if ($this->pneu < 30) {
            echo "<p>O pneu esta muxo precisa calibrar !</p>" ;
        } else {
            echo "<p>O pneu esta calibrado podemos rodar ...</p>" ;
        }
    }
}





?>

