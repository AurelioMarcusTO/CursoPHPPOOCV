<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Carro</title>
    </head>
    <body>
        <?php
        require_once 'Carro.php' ;
        
        $c1 = new Carro ;
        $c1->modelo = "Ferrari";
        $c1->cor = "vermelho";
        $c1->tipo = "sport" ;
        $c1->motor = 3.1 ;
        $c1->abastecimento = 70 ;
        $c1->combustivel = "gasolina" ;
        $c1->rodas = 20 ;
        $c1->pneu = 31 ;
        $c1->rodar();
        $c1->correr();
        $c1->calibrar();
        print_r($c1);
        
        echo "<br/>---------------------------------<br/>" ;
        
        $c2 = new Carro ;
        $c2->modelo = "Palio";
        $c2->cor = "prata" ;
        $c2->tipo = "passeio" ;
        $c2->motor = 1.1 ;
        $c2->abastecimento = 50 ;
        $c2->rodar();
        $c2->correr();
        $c2->calibrar();
        print_r($c2) ;
        
        echo "<br/>---------------------------------<br/>" ;
                
        $c3 = new Carro ;
        $c3->modelo = "Sandero";
        $c3->cor = "preto" ;
        $c3->motor = 1.8 ;
        $c3->rodas = 16 ;
        $c3->combustivel = "alcool" ;
        $c3->pneu = 30 ;
        $c3->calibrar();
        $c3->estacionar();
        $c3->rodar();
        print_r($c3);
        
        ?>
    </body>
</html>
