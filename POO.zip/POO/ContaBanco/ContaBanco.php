<?php

class ContaBanco {
   
    public $numconta ;
    protected $tipo ;
    //public $valor ;
    private $dono ;
    private $saldo ;
    private $status;
    
    function ContaBanco() {
       $this->setSaldo(0) ;
       $this->setStatus(false) ;
       echo "<p>Conta criada com sucesso !</p>" ;
    }
    
    //Metódos Especiais
    function getnumConta() {
        return $this->numconta ;
    }
    function setnumConta($numconta) {
        $this->numconta = $numconta ;
    }
    function gettipo() {
        return $this->tipo ;
    }
    function settipo($tipo) {
        $this->tipo = $tipo ;
    }
    function getdono() {
        return $this->dono ;
    }
    function setdono($dono) {
        $this->dono = $dono ;
    }
    function getsaldo() {
        return $this->saldo ;
    }
    function setsaldo($saldo) {
        $this->saldo = $saldo ;
    }
    function getstatus() {
        return $this->status ;
    }
    function setstatus($status) {
        $this->status = $status ;
    }
    
    //Métodos
    public function abrirConta($tipo) {
        $this->setTipo($tipo) ;
        $this->setStatus(true) ;
        if ($tipo == "cc") {
            $this->setSaldo(50) ;
        } elseif ($tipo == "cp") {
            $this->saldo = 150 ;
        }
    }
    public function fecharConta() {
        if ($this->getSaldo() > 0) {
            Echo "<p>Conta com Dinheiro, não posso fecha-la !.</p>" ;
        } elseif ($this->getSaldo() < 0) {
            echo "<p>Conta em Débito.</p>" ;
        } else {
            $this->setStatus(false);
            echo "<p>Conta de ".$this->getDono()." fechada com sucesso.</p>";
        }
    }
    public function Depositar($valor) {
        if ($this->getStatus() == true) {
            $this->setSaldo($this->getSaldo() + $valor) ;
            echo "Deposito de R$ $valor na conta de ".$this->getDono()."</p>";
        } else {
            echo "<p>Conta fechada,impossível Depositar !</p>" ;
        }
    }
    public function Sacar($valor) {
        if ($this->getStatus() == true) {
            if ($this->getSaldo() >= $valor){
                $this->setSaldo($this->getSaldo() - $valor);
                echo "<p>Saque de R$ $valor na conta de ".$this->getDono()."</p>";
            } else{
                echo "<p>Saldo insuficiente para saque na conta de ".$this->getDono()."</p>" ;
            }
        } else {
            echo "<p>Impossível sacar, conta fechada !</p>";
        }
    }
    public function pagarMensal() {
          if ($this->getTipo() == "cc") {
            $v = 12 ;
        } elseif ($this->getTipo() == "cp") {
            $v = 20 ;
        }
        if ($this->getStatus() == true) {
            if ($this->getSaldo() > $v) {
                $this->setSaldo($this->getSaldo() - $v) ;
                echo "<p>Mensalidade de R$ $v debitada da conta de ".$this->getDono()."</p>";
            } else {
                echo "<p>Saldo Insuficiente, não posso cobra a mensalidade !</p>" ;
            }
        } else {
            echo "<p>Impossivel cobrar a mensalidade !</p>" ;
        }
    }
}
