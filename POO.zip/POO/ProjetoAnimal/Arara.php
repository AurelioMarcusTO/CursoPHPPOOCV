<?php
require_once 'Ave.php';

class Arara extends Ave {
    
}
