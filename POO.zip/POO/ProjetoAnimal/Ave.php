<?php
require_once 'Animal.php';

class Ave extends Animal {
    private $corpena;
    
    //Metodos
    public function alimentar() {
       echo "<p>A ave esta comendo frutas !</p>"; 
    }

    public function emitirSom() {
       echo "<p>A ave esta Cantando !</p>"; 
    }

    public function locomover() {
       echo "<p>A ave esta voando !</p>"; 
    }
    
    public function fazerNinho(){
       echo "<p>A ave esta fazendo seu ninho !</p>"; 
    }
    
    //Metodos Especiais
    public function getcorPena(){
        return $this->corpena;
    }
    public function setcorPena($corpena){
        $this->corpena = $corpena;
    }

}
