<?php
require_once 'Animal.php';
require_once 'Mamifero.php';

class Cachorro extends Mamifero {
    
//Metodos
public function enterrarOsso(){
    echo "<p>Cachorro enterrando o osso !</p>";
}    
public function abanarRabo(){
    echo "<p>Cachorro abanando o rabo !</p>";
}
public function emitirSom(){
    echo "<p>Cachorro Latindo !</p>";
}
    
}
