<?php
require_once 'Animal.php';
require_once 'Mamifero.php';

class Canguru extends Mamifero {
    
//Metodos    
    public function usarBolsa(){
      echo "<p>Esta com o bebe em sua bolsa !</p>";  
    }
    
    public function locomover(){
        echo "<p>O canguru esta saltando !</p>";
    }
    
}
