<?php
require_once 'Peixe.php';

class Goldfish extends Peixe {
    
}
