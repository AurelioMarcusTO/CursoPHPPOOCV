<?php
require_once 'Animal.php';

class Mamifero extends Animal {
    private $corpelo;
    
    //Metodos
    public function alimentar() {
     echo "<p>Animal esta Mamando !</p>";   
    }

    public function emitirSom() {
     echo "<p>Som de Mamífero !</p>";   
    }

    public function locomover() {
      echo "<p>Animal esta Correndo !</p>";  
    }
    
    //Metodos Especiais
    public function getcorPelo(){
        return $this->corpelo;
    }
    public function setcorPelo($corpelo){
        $this->corpelo = $corpelo;
    }

}
