<?php
require_once 'Animal.php';

class Peixe extends Animal {
    private $corescama;
    
    //Metodos
    public function alimentar() {
      echo "<p>Peixe esta comendo substancias !</p>";  
    }

    public function emitirSom() {
      echo "<p>Peixe não faz som !</p>";  
    }

    public function locomover() {
      echo "<p>Peixe esta nadando !</p>";  
    }
    
    public function soltarBolha(){
        echo "<p>Peixe soltou uma bolha !</p>";
    }
    
    //Metodos Especiais
    public function getcorEscama(){
        return $this->corescama;
    }
    public function setcorEscama($corescama){
        $this->corescama = $corescama;
    }

}
