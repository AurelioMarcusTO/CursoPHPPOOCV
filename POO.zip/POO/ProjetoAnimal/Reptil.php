<?php
require_once 'Animal.php';

class Reptil extends Animal {
    private $corescama;
    
    //Metodos
    public function alimentar() {
      echo "<p>O Reptil esta comendo Vegetais !</p>";  
    }

    public function emitirSom() {
      echo "<p>Som de Reptil !</p>";  
    }

    public function locomover() {
      echo "<p>O Reptil esta rastejando !</p>";  
    }
    
    //Metodos Especiais
    public function getcorEscama(){
        return $this->corescama;
    }
    public function setcorEscama($corescama){
        $this->corescama = $corescama;
    }

}
