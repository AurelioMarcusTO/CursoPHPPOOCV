<?php
require_once 'Reptil.php';

class Tartaruga extends Reptil {
    
//Metodos
public function locomover(){
    echo "<p>Tartaruga andando beeem devagar !</p>";
}    
}
