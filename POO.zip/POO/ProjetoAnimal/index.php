<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Projeto Animais</title>
    </head>
    <body>
        <pre>
        <?php
        require_once 'Animal.php';
        require_once 'Mamifero.php';
        require_once 'Reptil.php';
        require_once 'Peixe.php';
        require_once 'Ave.php';
        require_once 'Canguru.php';
        require_once 'Cachorro.php';
        require_once 'Cobra.php';
        require_once 'Tartaruga.php';
        
        $m = new Mamifero();
        $m->setPeso(85.3);
        $m->setIdade(2);
        $m->setMembros(4);
        $m->setcorPelo("Marron");
        $m->locomover();
        $m->alimentar();
        $m->emitirSom();
        print_r($m);
        
        $p = new Peixe();
        $p->setPeso(0.35);
        $p->setIdade(1);
        $p->setMembros(0);
        $p->setcorEscama("Prata");
        $p->locomover();
        $p->alimentar();
        $p->emitirSom();
        $p->soltarBolha();
        print_r($p);
        
        $a = new Ave();
        $a->setPeso(0.89);
        $a->setIdade(2);
        $a->setMembros(2);
        $a->setcorPena("Azul");
        $a->locomover();
        $a->alimentar();
        $a->emitirSom();
        $a->fazerNinho();
        print_r($a);
        
        $c = new Canguru();
        $c->setPeso(55.30);
        $c->setIdade(3);
        $c->setMembros(4);
        $c->locomover();
        $c->alimentar();
        $c->usarBolsa();
        print_r($c);
        
        $k = new Cachorro();
        $k->setPeso(3.94);
        $k->setIdade(5);
        $k->setMembros(4);
        $k->setcorPelo("Marron");
        $k->enterrarOsso();
        $k->abanarRabo();
        $k->emitirSom();
        $k->locomover();
        print_r($k);
        
        $cb = new Cobra();
        $cb->locomover();
        print_r($cb);
        
        $t = new Tartaruga();
        $t->locomover();
        print_r($t);
        
        
        ?>
        </pre>
    </body>
</html>
