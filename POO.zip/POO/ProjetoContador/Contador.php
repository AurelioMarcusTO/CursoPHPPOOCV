<?php

class Contador {
    public $c;
    public $n;
    
//Metodos
function contprog($n){
    for($c = 0;$c <= $n;$c += 1){
        echo $c. " ";
    }
    echo "</br>";
}
function contreg($n){
    for($c = $n;$c >= 0;$c -= 1){
        echo $c. " ";
    }
}
}
