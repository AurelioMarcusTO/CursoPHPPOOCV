<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Contador</title>
    </head>
    <body><pre>
        <?php
        require_once 'Contador.php';
        
        $cont = new Contador();
        $cont->contprog(30);
        echo "</br>";
        $cont->contreg(30);
        
        
        ?>
        </pre>
    </body>
</html>
