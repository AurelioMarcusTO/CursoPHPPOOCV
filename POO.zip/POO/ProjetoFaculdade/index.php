�ィのアカウント（ YouTubeやFacebook、Twitter ）でソフトウェアを登録している场合、アカウント情报を利用して机能を有効にすることができます。</PurchaseResultPage_ThirdPartyLoginTip>
    <INF_Blacklist>アカウントに問題があります。現在のアカウントからログアウトして、再度購入ページに移動します。注文が完了した後、新しいアカウントとパスワードを使用して機能を有効にしてください。</INF_Blacklist>

    <PurchasePage_BuyPersons>{0}人が購入しました</PurchasePage_BuyPersons>
    <PurchaseHintForm_lbVersionIntroduce_Trail>一部の機能しか利用できません。製品版を入手するには、ネットワークに接続する状態でご購入ください。</PurchaseHintForm_lbVersionIntroduce_Trail>
    <PurchaseHintForm_LoadError>申し訳ございませんが、読み込みが失敗しました。</PurchaseHintForm_LoadError>
    <PurchaseResultPage_Function>機能</PurchaseResultPage_Function>
    <PurchaseResu