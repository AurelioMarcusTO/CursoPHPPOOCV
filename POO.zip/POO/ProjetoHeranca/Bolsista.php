<?php
require_once 'Pessoa.php';
require_once 'Aluno.php';

class Bolsista extends Aluno {
    private $bolsa;
    
//Metodos
public function renovarBolsa(){
    
}   
public function pagarMensalidade(){
  echo "<p>$this->nome é Bolsista! Então paga com Desconto!</p>";  
}
//Metodos Especiais
public function getBolsa(){
    return $this->bolsa;
}
public function setBolsa($bolsa){
    $this->bolsa = $bolsa;
}
}
