<?php
require_once 'Pessoa.php';
require_once 'Aluno.php';

class Tecnico extends Aluno {
   private $registroprofissional;
   
//Metodos
public function Praticar(){
  echo "<p>O técnico $this->nome está praticando.</p>";
  echo "<p>E vai receber o registro profissional: $this->registroprofissional .</p>";
}   
//Metodos Especiais
public function getRegistroProfissional(){
    return $this->registroprofissional;
}
public function setRegistroProfissional($registroprofissional){
    $this->registroprofissional = $registroprofissional;
}
}
