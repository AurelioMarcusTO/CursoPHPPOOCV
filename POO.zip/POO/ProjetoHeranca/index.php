﻿<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<LanguageResource Id="pt-PT" Name="Portuguese" LocaleName="Português" Version="1.1" LangID="0x0816" CodePage="1252">
  <Default>
    <Font Name="Tahoma" Size="8" />
    <FontMapping>
      <Item From="微软雅黑" To="Tahoma" />
      <Item From="宋体" To="Tahoma" />
    </FontMapping>
  </Default>
  <Strings>

    <!--消息框按扭文字-->
    <INF_Yes>Sim</INF_Yes>
    <INF_No>Não</INF_No>
    <INF_OK>OK</INF_OK>
    <INF_Cancel>Cancelar</INF_Cancel>
    <INF_ReTry>Tentar novamente</INF_ReTry>
    <INF_Information>Informações</INF_Information>
    <INF_Error>Erro</INF_Error>

    <!--通用复用-->
    <INF_DownCompleted>Transferência concluída. No entanto, o programa está a ser executado. Clique em OK para terminar o programa e instalar a nova versão.</INF_DownCompleted>
    <INF_SystemErrorInfo>Ocorreu um erro do sistema desconhecido</INF_SystemErrorInfo>
    <INF_ImageFilter>Toda a