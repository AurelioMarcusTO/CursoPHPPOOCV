 </NewLoginPage>
    <LoginProcessingPage>
      <lbLoging Text="A iniciar sessão..." />
    </LoginProcessingPage>
    <LoginSuccessPage>
      <lbIntroduce Text="Need a few seconds, please later!" />
    </LoginSuccessPage>
    <EditProfilePage>
      <lbEmailIntroduce Text="E-mail:" />
      <lbNameIntroduce Text="Nome:" />
      <lbPhotoIntroduce Text="Foto de Perfil:" />
      <btnSelectImage Text="Escolha uma foto" />
      <lbImageIntroduce Text=".jpg,.gif ou .png. Tamanho máximo de arquivo de 1Mb" />
      <btnSave Text="Confirmar" />
      <btnCancel Text="Cancelar" />
      <btnBack Text="Editar Perfil" />
    </EditProfilePage>
    <ChangePasswordPage>
      <lbEmailIntroduce Text="E-mail:" />
      <lbOldPasswd Text="Senha Antiga:" />
      <lbNewPasswd Text="Nova Senha:" />
      <lbNewAgaingPasswd Text="Re-introduza a nova senha:" />
      <lbOldPasswdDescn Text="Sua senha atual" />
      <lbNewPasswdDescn Text="A senha deve conter entre 6-19 caracteres" />
      <lbNewPasswdAgainDescn Text="Confirmar senha" />
    </ChangePasswordPage>
    <EditProfileFailPage>
      <btnBack Text="Editar Perfil" />
      <btnClose Text="Fechar" />
    </EditProfileFailPage>
    <EditProfileSuccessPage>
      <lbSuccessInfo Text="Perfil alterado com sucesso, obrigado!" />
      <btnClose Text="Fechar" />
      <btnBack Text="Editar Perfil" />
    </EditProfileSuccessPage>
    <InstallAppsPage>
      <lbFailDesc Text="Instalação falhou, por favor tente instalar novamente." />
      <lbSuccessDesc Text="Instalação concluída!" />
      <btnRun Text="Executar" />
      <btnClose Text="Fechar" />
    </InstallAppsPage>
    <NoUserHeaderControl>
      <linkLogin Text="Bem-vindo, &lt;A&gt;Inicie sessão&lt;/A&gt;." />
    </NoUserHeaderControl>
    <NewRegisterPage>
      <lbSignUpTip Text="Inscrever"/>
      <linkRegIntroduce Text="Já tem uma conta? &lt;a&gt;Iniciar sessão&lt;/a&gt;" />
      <l