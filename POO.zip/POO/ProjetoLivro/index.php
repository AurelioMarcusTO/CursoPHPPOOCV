ar das funções premium.</License_NoLicenseToBuy>
    <INF_CHANGEPASSWORD>Alterar Senha</INF_CHANGEPASSWORD>
    <INF_SIGNIN>Entre</INF_SIGNIN>
    <INF_SIGNOUT>Terminar sessão</INF_SIGNOUT>

    <!--卸载窗体-->
    <INF_UNINSTALL>Desinstalar {0}</INF_UNINSTALL>

    <!-- 代理配置窗体 -->
    <INF_LogSetting>Definições de login</INF_LogSetting>
    <INF_NetworkSetting>Definições de rede</INF_NetworkSetting>
    <INF_Type>Tipo</INF_Type>
    <INF_Address>Endereço</INF_Address>
    <INF_Port>Porta</INF_Port>
    <INF_Username>Nome de usuário</INF_Username>
    <INF_Password>Senha</INF_Password>
    <INF_Domain>Domínio</INF_Domain>
    <INF_Test>Teste</INF_Test>
    <INF_logInServer>Servidor</INF_logInServer>
    <INF_Confirm>Confirmar</INF_Confirm>
    <INF_NoProxy>Não usar proxy</INF_NoProxy>
    <INF_HttpProxy>Http proxy</INF_HttpProx