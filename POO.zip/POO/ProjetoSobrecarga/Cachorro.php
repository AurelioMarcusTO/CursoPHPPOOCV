</LicenseListPage>
    <LicenseRecommendItemControl>
      <btnPay Text="Más información" />
    </LicenseRecommendItemControl>
    <LicenseSeparatorControl>
      <lbIntroduce Text="No ha comprado ninguna función todavía." />
      <btnAppsolution Text="Buscar más aplicaciones" />
    </LicenseSeparatorControl>

    <!--购买界面-->
    <PurchaseForm>
      <btnClose ToolTip="Cerrar" />
    </PurchaseForm>
    <PurchaseErrorPage>
      <lbIntroduce Text="Esta es una función de pago. Cómprela para utilizarla." />
      <linkErrorText Text="Lo sentimos. Error al cargar." />
      <btnRetry Text="Reintentar" />
    </PurchaseErrorPage>
    <PurchasePage>
      <lbIntroduce Text="Esta es una función de pago. Cómprela para utilizarla." />
      <btnPayPal Text="Pagar con " />
      <btnCreditCard Text="Pagar con Tarjeta de Crédito" />
      <linkLearnMore Text="Más información &gt;&gt;" />
      <linkSkip Text="Omitir para usar directamente" />
    </PurchasePage>
    <PurchaseResultPage>
      <btnConfirm Text="Sí, lo tengo." /> 
      <btnPayAgain