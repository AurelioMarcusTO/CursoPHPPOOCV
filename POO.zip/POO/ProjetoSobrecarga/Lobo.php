<?php
require_once 'Mamifero.php';

class Lobo extends Mamifero {
    
    public function alimentar() {
        
    }

    public function emitirSom() {
      echo "<p>AAAaaaauuuuuuu !!!</p>";  
    }

    public function locomover() {
        
    }

}
