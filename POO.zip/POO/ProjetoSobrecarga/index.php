
<html>
    <head>
        <meta charset="UTF-8">
        <title>Sobrecarga</title>
    </head>
    <body>
        <pre>
        <?php
        require_once 'Lobo.php';
        require_once 'Cachorro.php';
        
        $l = new Lobo();
        $l->setPeso(35);
        $l->setIdade(12);
        $l->setcorPelo("Cinza");
        $l->emitirSom();
        print_r($l);
        
        $c = new Cachorro();
        $c->emitirSom();
        $c->reagirFrase("Olá");
        $c->reagirFrase("Vai Apanhar");
        $c->reagirIdadePeso(2, 12.5);
        $c->reagirIdadePeso(17, 4.5);
        print_r($c);
        
        ?>
        </pre>
    </body>
</html>
